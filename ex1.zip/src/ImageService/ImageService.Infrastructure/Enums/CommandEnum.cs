﻿namespace ImageService.Infrastructure.Enums
{
    public enum CommandEnum : int
    {
        NewFileCommand = 0,
        CloseCommand = 1
    }
}
