﻿namespace ImageService.Logging.Modal
{
    public enum MessageTypeEnum : int
    {
        INFO,
        WARNING,
        FAIL
    }
}
