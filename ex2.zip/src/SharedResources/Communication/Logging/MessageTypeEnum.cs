﻿namespace SharedResources.Logging
{
    public enum MessageTypeEnum : int
    {
        INFO, 
        WARNING,
        FAIL
    }
}
